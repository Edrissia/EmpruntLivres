import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { router, usePathname } from 'expo-router';

export default function BottomNav() {
  const current = usePathname();

  return (
    <View style={styles.nav}>
      <NavButton
        title=" Livres"
        active={current === '/books'}
        onPress={() => router.push('/books')}
      />
      <NavButton
        title=" Emprunts"
        active={current === '/loan'}
        onPress={() => router.push('/loan')}
      />
      <NavButton
        title=" Déconnexion"
        active={false}
        onPress={() => router.push('/')}
        customColor="#FF6B6B"
      />
    </View>
  );
}

function NavButton({ title, active, onPress, customColor }: any) {
  return (
    <TouchableOpacity
      style={[styles.button, active && styles.activeButton]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <Text style={[styles.buttonText, active && styles.activeButtonText, customColor && { color: customColor }]}>
        {title}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  nav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 14,
    borderTopWidth: 1,
    borderColor: '#ddd',
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: -3 },
    shadowRadius: 5,
    elevation: 10,
  },
  button: {
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
  },
  activeButton: {
    backgroundColor: '#007bff',
  },
  buttonText: {
    fontSize: 16,
    color: '#555',
    fontWeight: '600',
  },
  activeButtonText: {
    color: '#fff',
  },
});

import React, { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, StyleSheet, Platform, Alert, TextInput, ScrollView, TouchableOpacity } from 'react-native';
import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import { router } from 'expo-router';

export default function CrudStats() {
  const [loading, setLoading] = useState(true);

  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [copies, setCopies] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [bookList, setBookList] = useState([]);

  const fetchBooks = async () => {
    try {
      const token = await SecureStore.getItemAsync('userToken') || '';
      const res = await axios.get('http://172.20.10.2:3000/books', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setBookList(res.data);
    } catch (err) {
      console.log("❌ Erreur récupération livres :", err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddOrUpdate = async () => {
    try {
      const token = await SecureStore.getItemAsync('userToken') || '';
      if (editingId) {
        await axios.put(`http://172.20.10.2:3000/books/${editingId}`, {
          title,
          author,
          copies: parseInt(copies)
        }, {
          headers: { Authorization: `Bearer ${token}` }
        });
        Alert.alert("Succès", "Livre modifié !");
      } else {
        await axios.post('http://172.20.10.2:3000/books', {
          title,
          author,
          copies: parseInt(copies)
        }, {
          headers: { Authorization: `Bearer ${token}` }
        });
        Alert.alert("Succès", "Livre ajouté 📚!");
      }
      fetchBooks();
      setTitle('');
      setAuthor('');
      setCopies('');
      setEditingId(null);
    } catch (err) {
      Alert.alert("Erreur", "Échec de l'opération.");
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const token = await SecureStore.getItemAsync('userToken') || '';
      await axios.delete(`http://172.20.10.2:3000/books/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      Alert.alert("Supprimé", "Livre supprimé");
      fetchBooks();
    } catch (err) {
      Alert.alert("Erreur", "Suppression échouée");
    }
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}> Ajouter un livre 📚</Text>

      <TextInput
        placeholder="Titre"
        style={styles.input}
        value={title}
        onChangeText={setTitle}
      />
      <TextInput
        placeholder="Auteur"
        style={styles.input}
        value={author}
        onChangeText={setAuthor}
      />
      <TextInput
        placeholder="Nombre d'exemplaires"
        keyboardType="numeric"
        style={styles.input}
        value={copies}
        onChangeText={setCopies}
      />
      <TouchableOpacity style={styles.button} onPress={handleAddOrUpdate}>
        <Text style={styles.buttonText}>{editingId ? "Mettre à jour" : "Ajouter"}</Text>
      </TouchableOpacity>

      <Text style={styles.header}>📚Les livres disponibles:</Text>
      {loading ? (
        <ActivityIndicator size="large" color="#0000FF" />
      ) : (
        bookList.map((b: any) => (
          <View key={b.id} style={styles.card}>
            <Text style={styles.title}>{b.title}</Text>
            <Text>Auteur : {b.author} | Copies : {b.copies}</Text>
            <View style={styles.cardActions}>
              <TouchableOpacity style={styles.actionButton} onPress={() => {
                setTitle(b.title);
                setAuthor(b.author);
                setCopies(String(b.copies));
                setEditingId(b.id);
              }}>
                <Text style={styles.actionButtonText}>Modifier</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.actionButton, styles.deleteButton]} onPress={() => handleDelete(b.id)}>
                <Text style={styles.actionButtonText}>Supprimer</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))
      )}

      <View style={styles.logoutContainer}>
        <TouchableOpacity style={styles.button} onPress={async () => {
          await SecureStore.deleteItemAsync('userToken');
          await SecureStore.deleteItemAsync('userRole');
          await SecureStore.deleteItemAsync('userEmail');
          router.replace('/');
        }}>
          <Text style={styles.buttonText}>Déconnexion</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
    backgroundColor: '#f9f9f9',
  },
  header: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
    fontWeight: 'bold',
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 12,
    marginBottom: 15,
    borderRadius: 8,
    fontSize: 16,
    backgroundColor: '#fff',
  },
  button: {
    backgroundColor: '#1E90FF', // Bleu
    paddingVertical: 12,
    borderRadius: 25,
    marginVertical: 15,
    elevation: 5,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
  },
  card: {
    padding: 15,
    marginBottom: 20,
    backgroundColor: '#fff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#eee',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  cardActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  actionButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  actionButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  deleteButton: {
    backgroundColor: '#E53935',
  },
  logoutContainer: {
    marginTop: 20,
  },
});

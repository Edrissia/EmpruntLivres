import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, StyleSheet, Platform, Alert, TouchableOpacity } from 'react-native';
import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import { router } from 'expo-router';
import BottomNav from '@/components/BottomNav';
import { useFocusEffect } from '@react-navigation/native';
import { useCallback } from 'react';

export default function Books() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchBooks = async () => {
    setLoading(true);
    try {
      const token = await SecureStore.getItemAsync('userToken') || '';

      const response = await fetch('http://172.20.10.2:3000/books', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });

      const data = await response.json();
      console.log('📚 Données reçues de l’API :', data);
      setBooks(data);
    } catch (error) {
      console.error('❌ Erreur lors de la récupération des livres :', error);
      Alert.alert("Erreur", "Impossible de récupérer les livres");
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      fetchBooks();
    }, [])
  );

  const handleLoan = async (bookId: string) => {
    try {
      let token = '';
      if (Platform.OS !== 'web') {
        token = await SecureStore.getItemAsync('userToken') || '';
      }
      const borrower = await SecureStore.getItemAsync('userEmail');

      await axios.post('http://172.20.10.2:3000/loans', {
        bookId,
        borrower: borrower || 'inconnu'
      }, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      Alert.alert("Succès", "Livre emprunté !");
      router.push('/loan');
    } catch (err: any) {
      console.log("❌ Erreur emprunt :", err.response?.data || err.message);
      Alert.alert("Erreur", err.response?.data?.error || "Erreur emprunt");
    }
  };

  const renderBook = ({ item }: { item: any }) => (
    <View style={styles.card}>
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.author}>Auteur : {item.author}</Text>
      <Text style={styles.available}>Disponibles : {item.available} / {item.copies}</Text>
      {item.available > 0 && (
        <TouchableOpacity style={styles.loanButton} onPress={() => handleLoan(item.id)}>
          <Text style={styles.loanButtonText}>Emprunter</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>📚 Livres disponibles</Text>

      {loading ? (
        <ActivityIndicator size="large" color="#4CAF50" />
      ) : books.length > 0 ? (
        <FlatList
          data={books}
          keyExtractor={(item) => item.id}
          renderItem={renderBook}
          contentContainerStyle={styles.list}
        />
      ) : (
        <Text style={styles.noBooksText}>Aucun livre trouvé.</Text>
      )}

      <BottomNav />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f1f1f1',
    padding: 16,
    paddingTop: 40,
  },
  header: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2C3E50',
    marginBottom: 25,
    textAlign: 'center',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  card: {
    backgroundColor: '#ffffff',
    padding: 20,
    marginBottom: 15,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 5,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#34495E',
    marginBottom: 5,
  },
  author: {
    fontSize: 16,
    color: '#7F8C8D',
    marginBottom: 8,
  },
  available: {
    fontSize: 14,
    color: '#BDC3C7',
    marginBottom: 12,
  },
  loanButton: {
    backgroundColor: '#3498DB',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15,
    elevation: 2,
  },
  loanButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  noBooksText: {
    fontSize: 18,
    color: '#95A5A6',
    textAlign: 'center',
    marginTop: 20,
  },
  list: {
    paddingBottom: 60,
  },
});

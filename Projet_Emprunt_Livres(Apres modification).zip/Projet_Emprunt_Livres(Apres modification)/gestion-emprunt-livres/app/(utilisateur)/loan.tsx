import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, TouchableOpacity, Alert, Platform, StyleSheet } from 'react-native';
import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import BottomNav from '@/components/BottomNav';

type Book = {
  id: string;
  title: string;
  author: string;
  copies: number;
  available: number;
};

type Loan = {
  id: string;
  bookId: string;
  borrower: string;
  loanDate: string;
  returned: boolean;
  returnDate?: string;
};

export default function Loans() {
  const [loans, setLoans] = useState<Loan[]>([]);
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLoans = async (token: string) => {
    const res = await axios.get('http://172.20.10.2:3000/loans', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    setLoans(res.data);
  };

  const fetchBooks = async (token: string) => {
    const res = await axios.get('http://172.20.10.2:3000/books', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    setBooks(res.data);
  };

  const handleReturn = async (loanId: string) => {
    try {
      let token = '';
      if (Platform.OS !== 'web') {
        token = await SecureStore.getItemAsync('userToken') || '';
      }

      await axios.put(`http://172.20.10.2:3000/loans/${loanId}/return`, {}, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      Alert.alert("Succès", "Livre retourné !");
      await fetchLoans(token);
    } catch (err: any) {
      console.log("❌ Erreur retour :", err.response?.data || err.message);
      Alert.alert("Erreur", err.response?.data?.error || "Erreur retour");
    }
  };

  const getBookTitle = (bookId: string) => {
    const book = books.find((b) => b.id === bookId);
    return book ? book.title : `ID : ${bookId}`;
  };

  const renderLoan = ({ item }: { item: Loan }) => (
    <View style={styles.card}>
      <Text style={styles.title}>📘 {getBookTitle(item.bookId)}</Text>
      <Text style={styles.text}>Emprunté par : {item.borrower}</Text>
      <Text style={styles.text}>Date : {new Date(item.loanDate).toLocaleDateString()}</Text>
      <Text style={[styles.status, item.returned ? styles.returned : styles.borrowed]}>
        {item.returned ? '✔️ Retourné' : '📖 En cours'}
      </Text>

      {!item.returned && (
        <TouchableOpacity style={styles.returnButton} onPress={() => handleReturn(item.id)}>
          <Text style={styles.returnButtonText}>Retourner le livre</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  useEffect(() => {
    const init = async () => {
      try {
        let token = '';
        if (Platform.OS !== 'web') {
          token = await SecureStore.getItemAsync('userToken') || '';
        }

        await fetchBooks(token);
        await fetchLoans(token);
      } catch (err: any) {
        console.log("❌ Erreur chargement données :", err.message);
        Alert.alert("Erreur", err.message || "Erreur chargement");
      } finally {
        setLoading(false);
      }
    };

    init();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>📄 Mes emprunts</Text>

      {loading ? (
        <ActivityIndicator size="large" color="#4CAF50" />
      ) : loans.length > 0 ? (
        <FlatList
          data={loans}
          keyExtractor={(item) => item.id}
          renderItem={renderLoan}
        />
      ) : (
        <Text style={styles.noLoansText}>Aucun emprunt trouvé.</Text>
      )}
      
      <BottomNav />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
    backgroundColor: '#f7f7f7',
  },
  header: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    textTransform: 'uppercase',
    color: '#333',
  },
  card: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 6,
    color: '#333',
  },
  text: {
    fontSize: 14,
    color: '#555',
    marginBottom: 4,
  },
  status: {
    marginTop: 8,
    fontWeight: '600',
    fontSize: 14,
  },
  borrowed: {
    color: '#FF5722',
  },
  returned: {
    color: '#4CAF50',
  },
  returnButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 10,
    borderRadius: 8,
    marginTop: 12,
    alignItems: 'center',
  },
  returnButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  noLoansText: {
    fontSize: 18,
    color: '#777',
    textAlign: 'center',
    marginTop: 30,
  },
});

// server.js
require("dotenv").config();
const express = require("express");
const { v4: uuidv4 } = require("uuid");
const jwt = require("jsonwebtoken");
const rateLimit = require("express-rate-limit");
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(cors()); // ←  CORS activé

// Stockage en mémoire
const users = {}; // clé : email, valeur : { id, email, password }
let books = [];   // Liste des livres
let loans = [];   // Liste des emprunts


const mysql = require('mysql2');
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'bibliotheque'
});

db.connect((err) => {
  if (err) throw err;
  console.log("✅ Connecté à MySQL via WAMP");
});


// Fonction pour générer un token JWT
function generateToken(user) {
  return jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: process.env.TOKEN_EXPIRATION });
}


// Routes d'authentification

// Inscription : /register
app.post("/register", (req, res) => {
  const { email, password } = req.body;
  const role = email.includes("@admin.com") ? "admin" : "user";
  const id = uuidv4();

  db.query("SELECT * FROM users WHERE email = ?", [email], (err, results) => {
    if (err) return res.status(500).json({ error: "Erreur serveur" });
    if (results.length > 0) {
      return res.status(409).json({ error: "Utilisateur déjà inscrit" });
    }

    db.query("INSERT INTO users (id, email, password, role) VALUES (?, ?, ?, ?)",
      [id, email, password, role], (err2) => {
        if (err2) return res.status(500).json({ error: "Échec de l'inscription" });

        const token = jwt.sign({ id, email, role }, process.env.JWT_SECRET, { expiresIn: process.env.TOKEN_EXPIRATION });
        res.status(201).json({ token, role, message: "Inscription réussie" });
      }
    );
  });
});

// Connexion : /login
app.post("/login", (req, res) => {
  const { email, password } = req.body;
  db.query("SELECT * FROM users WHERE email = ?", [email], (err, results) => {
    if (err) return res.status(500).json({ error: "Erreur BDD" });
    if (!results[0] || results[0].password !== password) {
      return res.status(401).json({ error: "Identifiants invalides" });
    }

    const user = results[0];
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.TOKEN_EXPIRATION });

    res.status(200).json({ token, role: user.role, message: "Connexion réussie" });
  });
});


//middleware authorize() pour restreindre l’accès
const authorize = (role) => {
  return (req, res, next) => {
    if (req.user.role !== role) {
      return res.status(403).json({ error: "Accès refusé. Rôle requis : " + role });
    }
    next();
  };
};


// Middleware d'authentification (vérifie le token JWT)
const authenticate = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ error: "Token manquant" });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      console.log("❌ Token invalide :", token);
      return res.status(403).json({ error: "Token invalide" });
    }

    console.log("✅ Token valide, utilisateur :", user);
    req.user = user;
    next();
  });
};


// Middleware pour vérifier si l'utilisateur est un administrateur
const authorizeAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: "Accès refusé : administrateur uniquement" });
  }
  next();
};



// Rate limiter pour limiter les abus sur certaines routes
const theLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,  // 1 heure
  max: 100,                 // 100 requêtes par heure
  message: { error: "Trop de requêtes" }
});

// Applique le rate limiter aux routes sensibles
app.use(["/books", "/loans"], theLimiter);


// Routes protégées pour les Livres
// GET /books : Retourne la liste de tous les livres
app.get("/books", authenticate, (req, res) => {
  db.query("SELECT * FROM books", (err, results) => {
    if (err) return res.status(500).json({ error: "Erreur récupération livres" });
    res.status(200).json(results);
  });
});



// POST /books : Ajoute un nouveau livre
// Expects: { title: "Titre", author: "Auteur", copies: nombre }
app.post("/books", authenticate, authorize("admin"), (req, res) => {
  const { title, author, copies } = req.body;
  const id = uuidv4();
  db.query("INSERT INTO books (id, title, author, copies, available) VALUES (?, ?, ?, ?, ?)",
    [id, title, author, copies, copies],
    (err) => {
      if (err) return res.status(500).json({ error: "Erreur ajout livre" });
      res.status(201).json({ id, title, author, copies });
    });
});


// PUT /books/:id : Met à jour un livre existant
app.put("/books/:id", authenticate, authorize("admin"), (req, res) => {
  const { title, author, copies } = req.body;
  const id = req.params.id;

  db.query("SELECT * FROM books WHERE id = ?", [id], (err, result) => {
    if (err || !result[0]) return res.status(404).json({ error: "Livre non trouvé" });

    const book = result[0];
    const diff = copies - book.copies;
    const newAvailable = Math.max(book.available + diff, 0);

    db.query("UPDATE books SET title = ?, author = ?, copies = ?, available = ? WHERE id = ?",
      [title || book.title, author || book.author, copies || book.copies, newAvailable, id],
      (err2) => {
        if (err2) return res.status(500).json({ error: "Erreur mise à jour livre" });
        res.status(200).json({ id, title, author, copies });
      });
  });
});


// DELETE /books/:id : Supprime un livre
app.delete("/books/:id", authenticate, authorize("admin"), (req, res) => {
  db.query("DELETE FROM books WHERE id = ?", [req.params.id], (err) => {
    if (err) return res.status(500).json({ error: "Erreur suppression livre" });
    res.status(204).end();
  });
});

// POST /loans : Crée un nouvel emprunt
// Expects: { bookId: "ID_du_livre", borrower: "Nom de l'emprunteur" }
app.post("/loans", authenticate, (req, res) => {
  const { bookId, borrower } = req.body;
  const loanId = uuidv4();

  db.query("SELECT * FROM books WHERE id = ?", [bookId], (err, results) => {
    if (err || !results[0]) return res.status(404).json({ error: "Livre non trouvé" });
    const book = results[0];

    if (book.available <= 0) {
      return res.status(409).json({ error: "Aucun exemplaire disponible" });
    }

    db.query("INSERT INTO loans (id, bookId, userId, borrower, loanDate) VALUES (?, ?, ?, ?, NOW())",
      [loanId, bookId, req.user.id, borrower], (err2) => {
        if (err2) return res.status(500).json({ error: "Erreur création emprunt" });

        db.query("UPDATE books SET available = available - 1 WHERE id = ?", [bookId]);
        res.status(201).json({ id: loanId, bookId, borrower });
      });
  });
});


// PUT /loans/:id/return : Enregistre le retour d’un livre emprunté
app.put("/loans/:id/return", authenticate, (req, res) => {
  const id = req.params.id;

  db.query("SELECT * FROM loans WHERE id = ?", [id], (err, results) => {
    if (err || !results[0]) return res.status(404).json({ error: "Emprunt non trouvé" });
    const loan = results[0];

    if (loan.returned) {
      return res.status(409).json({ error: "Déjà retourné" });
    }

    db.query("UPDATE loans SET returned = 1, returnDate = NOW() WHERE id = ?", [id]);
    db.query("UPDATE books SET available = available + 1 WHERE id = ?", [loan.bookId]);

    res.status(200).json({ message: "Livre retourné" });
  });
});



//Lister tous les emprunts :

app.get("/loans", authenticate, (req, res) => {
  if (req.user.role === 'admin') {
    db.query("SELECT * FROM loans", (err, results) => {
      if (err) return res.status(500).json({ error: "Erreur chargement" });
      res.status(200).json(results);
    });
  } else {
    db.query("SELECT * FROM loans WHERE userId = ?", [req.user.id], (err, results) => {
      if (err) return res.status(500).json({ error: "Erreur chargement" });
      res.status(200).json(results);
    });
  }
});

app.get("/admin/stats", authenticate, authorizeAdmin, async (req, res) => {
  try {
    const [users] = await db.promise().query("SELECT COUNT(*) AS total FROM users");
    const [books] = await db.promise().query("SELECT COUNT(*) AS total FROM books");
    const [loans] = await db.promise().query("SELECT COUNT(*) AS total FROM loans");
    const [activeLoans] = await db.promise().query("SELECT COUNT(*) AS total FROM loans WHERE returned = 0");

    res.status(200).json({
      users: users[0].total,
      books: books[0].total,
      loans: loans[0].total,
      activeLoans: activeLoans[0].total
    });
  } catch (err) {
    console.error("Erreur /admin/stats :", err);
    res.status(500).json({ error: "Erreur récupération statistiques" });
  }
});

// Lancement du serveur
app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ Serveur démarré sur http://0.0.0.0:${PORT}`);
});


